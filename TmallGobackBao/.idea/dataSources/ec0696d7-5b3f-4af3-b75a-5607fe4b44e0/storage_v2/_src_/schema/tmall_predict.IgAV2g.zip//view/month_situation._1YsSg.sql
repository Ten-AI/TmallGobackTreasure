create view month_situation as select `tmall_predict`.`t_user_purchase`.`commodity_id`             AS `commodity_id`,
                                      substr(`tmall_predict`.`t_user_purchase`.`time_stamp`, 1, 1) AS `month_`,
                                      `tmall_predict`.`t_user_purchase`.`time_stamp`               AS `time_stamp`
                               from `tmall_predict`.`t_user_purchase`
                               where (length(`tmall_predict`.`t_user_purchase`.`time_stamp`) = 3)
                               union select `tmall_predict`.`t_user_purchase`.`commodity_id`             AS `commodity_id`,
                                            substr(`tmall_predict`.`t_user_purchase`.`time_stamp`, 1, 2) AS `month_`,
                                            `tmall_predict`.`t_user_purchase`.`time_stamp`               AS `time_stamp`
                                     from `tmall_predict`.`t_user_purchase`
                                     where (length(`tmall_predict`.`t_user_purchase`.`time_stamp`) = 4);

