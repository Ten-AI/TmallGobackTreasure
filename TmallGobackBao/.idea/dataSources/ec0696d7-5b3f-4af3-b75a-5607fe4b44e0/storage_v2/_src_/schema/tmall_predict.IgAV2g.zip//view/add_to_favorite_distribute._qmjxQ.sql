create view add_to_favorite_distribute as
  select `tmall_predict`.`t_user_add_to_favorite`.`commodity_id` AS `commodity_id`,
         `tmall_predict`.`t_commodity`.`brand_id`                AS `brand_id`,
         `tmall_predict`.`t_commodity`.`merchant_id`             AS `merchant_id`,
         `tmall_predict`.`t_commodity`.`commodity_brand`         AS `commodity_brand`
  from (`tmall_predict`.`t_user_add_to_favorite` left join `tmall_predict`.`t_commodity` on ((
    `tmall_predict`.`t_commodity`.`commodity_id` = `tmall_predict`.`t_user_add_to_favorite`.`commodity_id`)));

