create view a as
  select `tmall_predict`.`t_commodity`.`merchant_id`  AS `merchant_id`,
         `tmall_predict`.`t_commodity`.`commodity_id` AS `commodity_id`,
         `tmall_predict`.`t_commodity`.`price`        AS `price`
  from `tmall_predict`.`t_commodity`
         join `tmall_predict`.`t_user_purchase`
  where (`tmall_predict`.`t_commodity`.`commodity_id` = `tmall_predict`.`t_user_purchase`.`commodity_id`);

