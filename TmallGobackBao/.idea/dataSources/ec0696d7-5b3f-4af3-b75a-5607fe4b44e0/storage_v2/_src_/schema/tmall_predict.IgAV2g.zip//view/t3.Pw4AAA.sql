create view t3 as
  select `tmall_predict`.`t1`.`id`    AS `id`,
         `tmall_predict`.`t1`.`price` AS `price`,
         `tmall_predict`.`t2`.`time`  AS `time`
  from `tmall_predict`.`t1`
         join `tmall_predict`.`t2`
  where (`tmall_predict`.`t1`.`id` = `tmall_predict`.`t2`.`id`);

