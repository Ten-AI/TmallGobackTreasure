create view commodity_sale_info as
  select `a`.`commodity_id`             AS `commodity_id`,
         `a`.`merchant_id`              AS `merchant_id`,
         `a`.`price`                    AS `price`,
         `month_situation`.`month_`     AS `month_`,
         `month_situation`.`time_stamp` AS `time_stamp`
  from (`tmall_predict`.`a` left join `tmall_predict`.`month_situation` on ((`month_situation`.`commodity_id` =
                                                                             `a`.`commodity_id`)));

