create view add_to_cart_distribute as
  select `tmall_predict`.`t_user_add_to_cart`.`commodity_id` AS `commodity_id`,
         `tmall_predict`.`t_commodity`.`brand_id`            AS `brand_id`,
         `tmall_predict`.`t_commodity`.`merchant_id`         AS `merchant_id`,
         `tmall_predict`.`t_commodity`.`commodity_brand`     AS `commodity_brand`
  from (`tmall_predict`.`t_user_add_to_cart` left join `tmall_predict`.`t_commodity` on ((
    `tmall_predict`.`t_commodity`.`commodity_id` = `tmall_predict`.`t_user_add_to_cart`.`commodity_id`)));

